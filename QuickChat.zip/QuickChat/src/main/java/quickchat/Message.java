package quickchat;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * A single QuickChat message plus the shared state for all messages
 * sent while the program is running.
 */
public class Message {

    public static final int MAX_LENGTH = 250;

    public static final String LENGTH_OK = "Message ready to send.";
    public static final String CELL_OK = "Cell phone number successfully captured.";
    public static final String CELL_BAD =
            "Cell phone number is incorrectly formatted or does not contain an international code. "
                    + "Please correct the number and try again.";
    public static final String MSG_SENT = "Message successfully sent.";
    public static final String MSG_DISREGARD = "Press 0 to delete the message.";
    public static final String MSG_STORED = "Message successfully stored.";

    // Shared state (lives for as long as the program runs)
    private static final List<Message> sentMessages = new ArrayList<>();
    private static int totalSent = 0;
    private static Path storageFile = Paths.get("messages.json");

    // Per-message data
    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String message;
    private final String messageHash;

    /** Creates a message with a randomly generated ten-digit ID. */
    public Message(String recipient, String message, int messageNumber) {
        this(generateMessageID(), recipient, message, messageNumber);
    }

    /** Creates a message with a supplied ID (used for testing). */
    public Message(String messageID, String recipient, String message, int messageNumber) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.message = message;
        this.messageNumber = messageNumber;
        this.messageHash = createMessageHash();
    }

    /** Random ten-digit number (leading zeros allowed) stored as a String. */
    public static String generateMessageID() {
        long number = ThreadLocalRandom.current().nextLong(0L, 10_000_000_000L);
        return String.format("%010d", number);
    }

    /** The message ID must not be more than ten characters. */
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    /**
     * The number must start with an international code ("+" and the country code)
     * followed by no more than ten digits.
     */
    public String checkRecipientCell() {
        if (recipient != null && recipient.matches("^\\+\\d{1,3}\\d{7,10}$")) {
            return CELL_OK;
        }
        return CELL_BAD;
    }

    /** Checks the 250 character limit and returns the matching message. */
    public String checkMessageLength() {
        int length = message.length();
        if (length <= MAX_LENGTH) {
            return LENGTH_OK;
        }
        return "Message exceeds " + MAX_LENGTH + " characters by " + (length - MAX_LENGTH)
                + "; please reduce the size.";
    }

    /** First two digits of the ID : message number : FIRSTLAST (all caps). */
    public String createMessageHash() {
        String[] words = message.trim().split("\\s+");
        String first = clean(words[0]);
        String last = clean(words[words.length - 1]);
        String prefix = messageID.substring(0, Math.min(2, messageID.length()));
        return (prefix + ":" + messageNumber + ":" + first + last).toUpperCase();
    }

    private static String clean(String word) {
        return word.replaceAll("[^A-Za-z0-9]", "");
    }

    /**
     * 1 = send, 2 = disregard, 3 = store for later.
     * Returns the confirmation message for the chosen option.
     */
    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                sentMessages.add(this);
                totalSent++;
                return MSG_SENT;
            case 2:
                return MSG_DISREGARD;
            case 3:
                return storeMessage() ? MSG_STORED : "Message could not be stored.";
            default:
                return "Invalid option. Please choose 1 (Send), 2 (Disregard) or 3 (Store).";
        }
    }

    /** Returns the details of every message sent while the program is running. */
    public static String printMessages() {
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append(m.getDetails()).append(System.lineSeparator());
        }
        return sb.toString();
    }

    /** Total number of messages sent so far. */
    public static int returnTotalMessages() {
        return totalSent;
    }

    /** Appends this message to the JSON file, keeping any messages already stored. */
    public boolean storeMessage() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Type listType = new TypeToken<List<Message>>() { }.getType();
        try {
            List<Message> stored = new ArrayList<>();
            if (Files.exists(storageFile)) {
                String json = Files.readString(storageFile, StandardCharsets.UTF_8);
                List<Message> existing = gson.fromJson(json, listType);
                if (existing != null) {
                    stored.addAll(existing);
                }
            }
            stored.add(this);
            Files.writeString(storageFile, gson.toJson(stored, listType), StandardCharsets.UTF_8);
            return true;
        } catch (IOException | RuntimeException e) {
            return false;
        }
    }

    /** Message ID, Message Hash, Recipient, Message - in that order. */
    public String getDetails() {
        return "Message ID: " + messageID + System.lineSeparator()
                + "Message Hash: " + messageHash + System.lineSeparator()
                + "Recipient: " + recipient + System.lineSeparator()
                + "Message: " + message + System.lineSeparator();
    }

    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public int getMessageNumber() { return messageNumber; }

    // Helpers mainly for unit tests
    public static void resetState() {
        sentMessages.clear();
        totalSent = 0;
    }

    public static void setStorageFile(Path path) {
        storageFile = path;
    }
}
