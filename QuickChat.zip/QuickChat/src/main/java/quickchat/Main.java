package quickchat;

import java.util.Scanner;

public class Main {

    private static final Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        Login login = new Login();

        // --- Registration and login ---
        System.out.println("=== Register ===");
        while (true) {
            String u = prompt("Choose a username: ");
            String p = prompt("Choose a password (at least 8 characters): ");
            if (login.registerUser(u, p)) {
                System.out.println("Registration successful.");
                break;
            }
            System.out.println("Invalid details, please try again.");
        }

        boolean loggedIn = false;
        for (int attempt = 1; attempt <= 3 && !loggedIn; attempt++) {
            System.out.println("=== Login ===");
            String u = prompt("Username: ");
            String p = prompt("Password: ");
            loggedIn = login.loginUser(u, p);
            if (!loggedIn) {
                System.out.println("Incorrect username or password.");
            }
        }
        if (!loggedIn) {
            System.out.println("Too many failed attempts. Goodbye.");
            return;
        }

        // --- Application ---
        System.out.println("Welcome to QuickChat.");
        int limit = readInt("How many messages do you wish to enter? ", 1);
        int entered = 0;
        boolean running = true;

        while (running) {
            System.out.println();
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            int choice = readInt("Choose an option: ", 1);

            switch (choice) {
                case 1:
                    if (entered >= limit) {
                        System.out.println("You have already entered all " + limit + " messages.");
                    } else {
                        sendFlow(entered);
                        entered++;
                        if (entered == limit) {
                            System.out.println("Total messages sent: " + Message.returnTotalMessages());
                        }
                    }
                    break;
                case 2:
                    System.out.println("Coming Soon.");
                    break;
                case 3:
                    running = false;
                    break;
                default:
                    System.out.println("Please choose 1, 2 or 3.");
            }
        }

        System.out.println("Total messages sent: " + Message.returnTotalMessages());
        System.out.println("Goodbye.");
    }

    private static void sendFlow(int messageNumber) {
        // Recipient
        String recipient;
        while (true) {
            recipient = prompt("Recipient cell number (e.g. +27718693002): ");
            Message probe = new Message(recipient, "x", messageNumber);
            String result = probe.checkRecipientCell();
            System.out.println(result);
            if (result.equals(Message.CELL_OK)) {
                break;
            }
        }

        // Message text
        String text;
        while (true) {
            text = prompt("Enter your message: ");
            if (text.isBlank()) {
                System.out.println("Message cannot be empty.");
            } else if (text.length() > Message.MAX_LENGTH) {
                System.out.println("Please enter a message of less than 250 characters.");
            } else {
                System.out.println("Message sent");
                break;
            }
        }

        Message msg = new Message(recipient, text, messageNumber);

        // Send / disregard / store
        System.out.println("1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message to send later");
        int option = readInt("Choose an option: ", 1);
        while (option > 3) {
            option = readInt("Please choose 1, 2 or 3: ", 1);
        }

        String result = msg.SentMessage(option);
        System.out.println(result);

        if (option == 1) {
            System.out.println(msg.getDetails());
        } else if (option == 2) {
            String answer = prompt("> ");
            if (answer.equals("0")) {
                System.out.println("Message deleted.");
            }
        }
    }

    private static String prompt(String text) {
        System.out.print(text);
        return in.nextLine().trim();
    }

    private static int readInt(String text, int min) {
        while (true) {
            String line = prompt(text);
            try {
                int value = Integer.parseInt(line);
                if (value >= min) {
                    return value;
                }
            } catch (NumberFormatException ignored) {
                // fall through
            }
            System.out.println("Please enter a whole number of " + min + " or more.");
        }
    }
}
