package quickchat;

/**
 * Minimal registration/login so that only logged-in users can send messages.
 * Replace the rules below with the ones from your previous task if they differ.
 */
public class Login {

    private String username;
    private String password;

    public boolean registerUser(String username, String password) {
        if (username == null || username.isBlank() || password == null || password.length() < 8) {
            return false;
        }
        this.username = username;
        this.password = password;
        return true;
    }

    public boolean loginUser(String username, String password) {
        return this.username != null
                && this.username.equals(username)
                && this.password.equals(password);
    }
}
