package quickchat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class MessageTest {

    // Test data from the brief
    private static final String MSG1 = "Hi Mike, can you join us for dinner tonight?";
    private static final String NUM1 = "+27718693002";
    private static final String MSG2 = "Hi Keegan, did you receive the payment?";
    private static final String NUM2 = "08575975889";

    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp() {
        Message.resetState();
        Message.setStorageFile(tempDir.resolve("messages.json"));
    }

    // --- Message length ---
    @Test
    void messageLengthSuccess() {
        Message m = new Message(NUM1, MSG1, 0);
        assertEquals("Message ready to send.", m.checkMessageLength());
    }

    @Test
    void messageLengthFailure() {
        String longText = "a".repeat(260);
        Message m = new Message(NUM1, longText, 0);
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.",
                m.checkMessageLength());
    }

    // --- Recipient number ---
    @Test
    void recipientNumberSuccess() {
        Message m = new Message(NUM1, MSG1, 0);
        assertEquals("Cell phone number successfully captured.", m.checkRecipientCell());
    }

    @Test
    void recipientNumberFailure() {
        Message m = new Message(NUM2, MSG2, 1);
        assertEquals("Cell phone number is incorrectly formatted or does not contain an "
                + "international code. Please correct the number and try again.",
                m.checkRecipientCell());
    }

    // --- Message hash ---
    @Test
    void messageHashTestCase1() {
        Message m = new Message("0012345678", NUM1, MSG1, 0);
        assertEquals("00:0:HITONIGHT", m.createMessageHash());
    }

    @Test
    void messageHashLoop() {
        String[][] cases = {
                // id, number, message, expected
                {"0012345678", "0", MSG1, "00:0:HITONIGHT"},
                {"0112345678", "1", MSG2, "01:1:HIPAYMENT"},
                {"0012345678", "0", "Hi thanks", "00:0:HITHANKS"},
                {"9912345678", "2", "Call me later", "99:2:CALLLATER"},
        };
        for (String[] c : cases) {
            Message m = new Message(c[0], NUM1, c[2], Integer.parseInt(c[1]));
            assertEquals(c[3], m.createMessageHash(), "Hash for: " + c[2]);
        }
    }

    // --- Message ID ---
    @Test
    void messageIdIsCreated() {
        Message m = new Message(NUM1, MSG1, 0);
        assertTrue(m.checkMessageID());
        assertEquals(10, m.getMessageID().length());
        assertTrue(m.getMessageID().matches("\\d{10}"));
        System.out.println("Message ID generated: " + m.getMessageID());
    }

    @Test
    void messageIdTooLongFails() {
        Message m = new Message("12345678901", NUM1, MSG1, 0);
        assertFalse(m.checkMessageID());
    }

    // --- Send / disregard / store ---
    @Test
    void sentMessageSend() {
        Message m = new Message(NUM1, MSG1, 0);
        assertEquals("Message successfully sent.", m.SentMessage(1));
    }

    @Test
    void sentMessageDisregard() {
        Message m = new Message(NUM2, MSG2, 1);
        assertEquals("Press 0 to delete the message.", m.SentMessage(2));
    }

    @Test
    void sentMessageStore() throws IOException {
        Message m = new Message(NUM1, MSG1, 0);
        assertEquals("Message successfully stored.", m.SentMessage(3));
        String json = Files.readString(tempDir.resolve("messages.json"));
        assertTrue(json.contains(m.getMessageHash()));
    }

    @Test
    void storeKeepsEarlierMessages() throws IOException {
        new Message(NUM1, MSG1, 0).SentMessage(3);
        new Message(NUM1, MSG2, 1).SentMessage(3);
        String json = Files.readString(tempDir.resolve("messages.json"));
        assertTrue(json.contains("dinner"));
        assertTrue(json.contains("payment"));
    }

    // --- Totals and printing ---
    @Test
    void totalMessagesAndPrint() {
        Message m1 = new Message(NUM1, MSG1, 0);
        Message m2 = new Message(NUM2, MSG2, 1);
        m1.SentMessage(1); // send
        m2.SentMessage(2); // discard

        assertEquals(1, Message.returnTotalMessages());
        String printed = Message.printMessages();
        assertTrue(printed.contains(m1.getMessageHash()));
        assertFalse(printed.contains(m2.getMessageID()));
    }

    @Test
    void detailsAreInRequiredOrder() {
        Message m = new Message("0012345678", NUM1, MSG1, 0);
        String d = m.getDetails();
        int id = d.indexOf("Message ID");
        int hash = d.indexOf("Message Hash");
        int rec = d.indexOf("Recipient");
        int msg = d.lastIndexOf("Message:");
        assertTrue(id < hash && hash < rec && rec < msg);
    }
}
